library(readr)
library(dplyr)
library(tidyr)
library(stringr)

dir.create("data_rebuilt", showWarnings = FALSE)

num <- function(x) suppressWarnings(as.numeric(x))
pct <- function(x) round(num(x) * 100, 2)

hpsa_label <- function(x) {
  case_when(
    x == 0 ~ "Not designated",
    x == 1 ~ "Whole county HPSA",
    x == 2 ~ "Partial county HPSA",
    TRUE ~ "Not reported"
  )
}

chr <- read_csv(
  "source_extracts/chr_2025_georgia.csv",
  col_types = cols(`5-digit FIPS Code` = col_character(), .default = col_character()),
  show_col_types = FALSE
) %>%
  transmute(
    State = "Georgia",
    State_Abbr = "GA",
    County = Name,
    County_Name = str_remove(Name, " County$"),
    County_FIPS = `5-digit FIPS Code`,
    Population = num(`Population raw value`),
    Adult_Smoking_Pct = pct(`Adult Smoking raw value`),
    Uninsured_Pct = pct(`Uninsured raw value`)
  )

svi <- read_csv(
  "source_extracts/svi_2022_georgia.csv",
  col_types = cols(FIPS = col_character(), .default = col_character()),
  show_col_types = FALSE
) %>%
  transmute(
    County_FIPS = FIPS,
    SVI_Overall = if_else(num(RPL_THEMES) < 0, NA_real_, num(RPL_THEMES))
  )

ahrf <- read_csv(
  "source_extracts/ahrf_2025_georgia.csv",
  col_types = cols(fips_st_cnty = col_character(), .default = col_character()),
  show_col_types = FALSE
) %>%
  transmute(
    County_FIPS = fips_st_cnty,
    HPSA_Primary_Care_Label = hpsa_label(num(hpsa_prim_care_25))
  )

hrsa <- read_csv(
  "source_extracts/hrsa_health_centers_georgia.csv",
  col_types = cols(
    `State and County Federal Information Processing Standard Code` = col_character(),
    .default = col_character()
  ),
  show_col_types = FALSE
) %>%
  transmute(
    State = "Georgia",
    State_Abbr = "GA",
    County = `Complete County Name`,
    County_FIPS = `State and County Federal Information Processing Standard Code`,
    Site_Name = `Site Name`,
    Site_Address = `Site Address`,
    Site_City = `Site City`,
    Site_ZIP = `Site Postal Code`,
    Latitude = num(`Geocoding Artifact Address Primary Y Coordinate`),
    Longitude = num(`Geocoding Artifact Address Primary X Coordinate`),
    Operating_Hours_per_Week = num(`Operating Hours per Week`),
    Health_Center_Type = `Health Center Type`,
    Site_Type = `Health Center Type Description`,
    Health_Center_Name = `Health Center Name`,
    Location_Setting = `Health Center Service Delivery Site Location Setting Description`,
    Operating_Schedule = `Health Center Operational Schedule Description`,
    Site_Status = `Site Status Description`
  )

hrsa_summary <- hrsa %>%
  group_by(County_FIPS) %>%
  summarise(
    HRSA_Site_Count = n(),
    HRSA_Avg_Operating_Hours_Week = mean(Operating_Hours_per_Week, na.rm = TRUE),
    .groups = "drop"
  )

county_master <- chr %>%
  left_join(svi, by = "County_FIPS") %>%
  left_join(ahrf, by = "County_FIPS") %>%
  left_join(hrsa_summary, by = "County_FIPS") %>%
  mutate(
    HRSA_Site_Count = replace_na(HRSA_Site_Count, 0L),
    HRSA_Avg_Operating_Hours_Week =
      if_else(HRSA_Site_Count == 0, NA_real_, HRSA_Avg_Operating_Hours_Week),
    HRSA_Sites_per_100k =
      round(HRSA_Site_Count / Population * 100000, 2),
    Has_HRSA_Site = if_else(HRSA_Site_Count > 0, "Yes", "No")
  )

site_type_count <- hrsa %>%
  count(County_FIPS, Site_Type, name = "Pie_Slice_Count")

pie_map <- county_master %>%
  left_join(site_type_count, by = "County_FIPS") %>%
  mutate(
    Pie_Slice =
      if_else(HRSA_Site_Count == 0, "No HRSA Site", Site_Type),
    Pie_Slice_Count =
      if_else(HRSA_Site_Count == 0, 0L, Pie_Slice_Count),
    Pie_Angle_Value =
      if_else(HRSA_Site_Count == 0, 1L, Pie_Slice_Count),
    Pie_Size_Display =
      if_else(HRSA_Site_Count == 0, 1, HRSA_Site_Count),
    Pie_Actual_Total_HRSA_Sites = HRSA_Site_Count,
    Pie_Note =
      if_else(
        HRSA_Site_Count == 0,
        "Display-only slice so counties with zero HRSA sites remain visible.",
        "Actual HRSA site-type composition."
      )
  ) %>%
  filter(HRSA_Site_Count == 0 | !is.na(Site_Type))

state_summary <- bind_rows(
  county_master %>%
    count(HPSA_Primary_Care_Label, name = "Count") %>%
    mutate(
      Summary_Name = "Primary Care HPSA Status",
      Category = HPSA_Primary_Care_Label,
      Percent = round(Count / sum(Count) * 100, 2)
    ) %>%
    select(Summary_Name, Category, Count, Percent),

  hrsa %>%
    count(Site_Type, name = "Count") %>%
    mutate(
      Summary_Name = "HRSA Site Type",
      Category = Site_Type,
      Percent = round(Count / sum(Count) * 100, 2)
    ) %>%
    select(Summary_Name, Category, Count, Percent)
)

write_csv(county_master, "data_rebuilt/georgia_county_master.csv")
write_csv(hrsa, "data_rebuilt/georgia_hrsa_sites.csv")
write_csv(pie_map, "data_rebuilt/georgia_county_hrsa_pie_map.csv")
write_csv(state_summary, "data_rebuilt/georgia_state_summaries.csv")

cat("Counties:", nrow(county_master), "\n")
cat("HRSA records:", nrow(hrsa), "\n")
