# Data Sources

## HRSA Health Centers
https://data.hrsa.gov/data/download

Used for health-center site records, site type, location, and operating hours.

## HRSA Area Health Resources Files (AHRF) 2025
https://data.hrsa.gov/topics/health-workforce/ahrf

Used for county primary care HPSA designation.

## County Health Rankings 2025
https://www.countyhealthrankings.org/health-data

Used for county adult smoking and uninsured percentages and population context.

## CDC/ATSDR Social Vulnerability Index 2022
https://www.atsdr.cdc.gov/place-health/php/svi/index.html

Used for county-level SVI Overall.

## Geographic note

The dashboard uses Tableau's built-in Georgia county geography with `County_Name` and `State`.
