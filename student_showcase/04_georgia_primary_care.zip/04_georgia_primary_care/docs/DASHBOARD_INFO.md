# Fourth Student Showcase Dashboard

## Title
**Primary Care in Georgia**

## Subtitle
**Shortage designations and HRSA health-center mix by county**

## Research question
**How do primary care shortage designations and the mix of HRSA health-center resources vary across Georgia counties?**

## Data sources
- HRSA Health Centers
- HRSA Area Health Resources Files (AHRF) 2025
- County Health Rankings 2025
- CDC/ATSDR Social Vulnerability Index 2022

## Dashboard link
https://public.tableau.com/views/GeorgiaPrimaryCareMosaic/DPrimaryCareinGeorgia?:language=en-US&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link

## Short description
An interactive Georgia county dashboard combining primary care HPSA designations with county-level HRSA health-center site composition. Selecting a county reveals a profile with health-center records, average operating hours, uninsured percentage, adult smoking percentage, and overall SVI.

## Student Showcase footer text
Explore an interactive Georgia dashboard examining primary care shortage designations, HRSA health-center mix, and selected county health indicators.
