# Tableau Calculated Fields

## Pie Size Scaled

Used to compress the pie-size range so very large counties do not visually dominate the map.

```tableau
SQRT([Pie Size Display])
```

Place `MIN(Pie Size Scaled)` on Size.

## HPSA County Count

```tableau
{ FIXED [HPSA Primary Care Label] : COUNTD([County FIPS]) }
```

Place `MIN(HPSA County Count)` on Angle for the Georgia HPSA Status pie.

## Georgia County Total

```tableau
{ FIXED : COUNTD([County FIPS]) }
```

## HPSA County Share

```tableau
[HPSA County Count] / [Georgia County Total]
```

Format as Percentage with 1 decimal place.

## County Profile Display

This field allows the county profile worksheet to display an instruction when no single county is selected.

```tableau
IF COUNTD([County Name]) = 1 THEN

    ATTR([County Name])

    + CHAR(10) + CHAR(10) +
    "Primary Care HPSA: " +
    ATTR([HPSA Primary Care Label])

    + CHAR(10) +
    "HRSA Health Center Records: " +
    STR(INT(MIN([HRSA Site Count])))

    + CHAR(10) +
    "Average Operating Hours: " +
    IF ISNULL(MIN([HRSA Avg Operating Hours Week])) THEN
        "Not reported"
    ELSE
        STR(ROUND(MIN([HRSA Avg Operating Hours Week]),1)) + " hrs/week"
    END

    + CHAR(10) +
    "Uninsured Rate: " +
    STR(ROUND(MIN([Uninsured Pct]),1)) + "%"

    + CHAR(10) +
    "Adult Smoking Rate: " +
    STR(ROUND(MIN([Adult Smoking Pct]),1)) + "%"

    + CHAR(10) +
    "SVI Overall Rate: " +
    STR(ROUND(MIN([SVI Overall]),2))

ELSE

    "Select a County On the Map for Details"

END
```

## Dashboard actions

### Map to county profile
- Source: `Primary Care Mosaic Map`
- Run action on: Select
- Target: `Selected County Profile`
- Selected field: `County Name` → `County Name`
- Clearing selection: Show all values

### Georgia HPSA Status to map
Use a **Highlight action** rather than a Filter action if you want the full Georgia map to remain visible.
- Source: `Georgia HPSA Status`
- Target: `Primary Care Mosaic Map`
- Field: `HPSA Primary Care Label`
