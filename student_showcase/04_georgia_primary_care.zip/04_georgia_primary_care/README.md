# Primary Care in Georgia

**Dashboard:** https://public.tableau.com/views/GeorgiaPrimaryCareMosaic/DPrimaryCareinGeorgia?:language=en-US&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link

## Research question

**How do primary care shortage designations and the mix of HRSA health-center resources vary across Georgia counties?**

## Dashboard design

The dashboard uses a dual-axis Georgia county map:

- County fill: primary care HPSA status
- County pie color: HRSA site type
- County pie size: total HRSA site records
- State summary pie: Georgia counties by primary care HPSA status
- Interactive county profile: HPSA status, HRSA records, average operating hours, uninsured percentage, adult smoking percentage, and SVI overall

The final dashboard intentionally avoids a KPI strip and uses the map as the main visual.

## Tableau-ready files

- `data/georgia_county_hrsa_pie_map.csv` — main dual-axis map data
- `data/georgia_county_master.csv` — one row per Georgia county
- `data/georgia_hrsa_sites.csv` — Georgia HRSA site-level records
- `data/georgia_state_summaries.csv` — state-level HPSA and HRSA summaries
- `data/georgia_data_dictionary.csv` — field definitions and recommended Tableau aggregations

## Reproducibility materials

- `source_extracts/` — Georgia-only extracts from the public source datasets
- `scripts/01_build_primary_care_in_georgia.R` — rebuilds the Tableau-ready files
- `docs/TABLEAU_CALCULATED_FIELDS.md` — calculated fields used in the workbook
- `docs/SOURCES.md` — source documentation
- `docs/DASHBOARD_INFO.md` — concise information for the fourth Student Showcase entry

## Data sources

- HRSA Health Centers
- HRSA Area Health Resources Files (AHRF) 2025
- County Health Rankings 2025
- CDC/ATSDR Social Vulnerability Index 2022

## Geographic scope

Georgia's 159 counties.

## Prepared-data checks

- Georgia counties: 159
- HRSA site records: 464
- Whole county primary care HPSA: 46 counties
- Partial county primary care HPSA: 100 counties
- Not designated: 13 counties

For county-level fields in `georgia_county_hrsa_pie_map.csv`, use `MIN` or `AVG`, not `SUM`, because a county can appear on multiple rows for different pie slices.
