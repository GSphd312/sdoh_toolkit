library(readr)
library(dplyr)

dir.create("derived", showWarnings = FALSE)

eji <- read_csv(
  "data/illinois_census_tract_tableau.csv",
  col_types = cols(Tract_FIPS = col_character(), County_FIPS = col_character()),
  show_col_types = FALSE
)

food <- read_csv(
  "data/illinois_food_access_tableau.csv",
  col_types = cols(Tract_FIPS = col_character()),
  show_col_types = FALSE
)

analysis <- eji %>%
  left_join(
    food %>% select(
      Tract_FIPS,
      LowIncome_LowAccess_HalfMile10mi,
      LowAccess_Pop_HalfMile_Pct,
      LowIncome_LowAccess_Pop_HalfMile_Pct
    ),
    by = "Tract_FIPS"
  ) %>%
  mutate(
    EJI_Valid = if_else(
      !is.na(EJI_Overall_Percentile) &
        EJI_Overall_Percentile >= 0 & EJI_Overall_Percentile <= 1,
      TRUE, FALSE
    ),
    Double_Burden_Class = case_when(
      is.na(LowIncome_LowAccess_HalfMile10mi) ~ "No USDA Match",
      EJI_Valid & EJI_Overall_Percentile >= 0.75 &
        LowIncome_LowAccess_HalfMile10mi == 1 ~ "Double Burden",
      EJI_Valid & EJI_Overall_Percentile >= 0.75 ~ "High EJI Only",
      LowIncome_LowAccess_HalfMile10mi == 1 ~ "Low-Income / Low-Access Only",
      TRUE ~ "Neither"
    ),
    Double_Burden_Share_Flag = case_when(
      Double_Burden_Class == "No USDA Match" ~ NA_real_,
      Double_Burden_Class == "Double Burden" ~ 1,
      TRUE ~ 0
    )
  )

county_summary <- analysis %>%
  group_by(County, County_FIPS) %>%
  summarise(
    Matched_Tracts = sum(!is.na(Double_Burden_Share_Flag)),
    Double_Burden_Tracts = sum(Double_Burden_Share_Flag == 1, na.rm = TRUE),
    Double_Burden_Share = mean(Double_Burden_Share_Flag, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(desc(Double_Burden_Share), desc(Matched_Tracts))

write_csv(analysis, "derived/illinois_tract_double_burden.csv")
write_csv(county_summary, "derived/illinois_county_double_burden_summary.csv")

cat("EJI tract rows:", nrow(eji), "\n")
cat("Food-access tract rows:", nrow(food), "\n")
cat("Matched tract IDs:", sum(eji$Tract_FIPS %in% food$Tract_FIPS), "\n")
