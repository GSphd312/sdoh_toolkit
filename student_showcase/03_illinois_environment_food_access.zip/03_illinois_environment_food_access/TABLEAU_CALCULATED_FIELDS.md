# Tableau calculated fields

## Double Burden Class

```tableau
IF ISNULL([LowIncome LowAccess HalfMile10mi]) THEN
    "No USDA Match"
ELSEIF [EJI Overall Percentile (illinois census tract tableau.csv1)] >= 0.75
AND [LowIncome LowAccess HalfMile10mi] = 1 THEN
    "Double Burden"
ELSEIF [EJI Overall Percentile (illinois census tract tableau.csv1)] >= 0.75 THEN
    "High EJI Only"
ELSEIF [LowIncome LowAccess HalfMile10mi] = 1 THEN
    "Low-Income / Low-Access Only"
ELSE
    "Neither"
END
```

## Double Burden Share Flag

```tableau
IF [Double Burden Class] = "No USDA Match" THEN NULL
ELSEIF [Double Burden Class] = "Double Burden" THEN 1
ELSE 0
END
```

Use `AVG([Double Burden Share Flag])` and format as a percentage for the county ranking.
