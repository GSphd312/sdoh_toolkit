# Data sources

- CDC/ATSDR Environmental Justice Index: https://www.atsdr.cdc.gov/place-health/php/eji/index.html
- USDA Food Access Research Atlas: https://www.ers.usda.gov/data-products/food-access-research-atlas/
- U.S. Census Bureau cartographic boundary files: https://www.census.gov/geographies/mapping-files/time-series/geo/cartographic-boundary.html
