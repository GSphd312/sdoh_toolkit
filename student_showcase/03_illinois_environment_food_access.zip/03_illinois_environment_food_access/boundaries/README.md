# Census tract boundary file

Use the U.S. Census Bureau 2024 Illinois 500k census tract cartographic boundary ZIP:

https://www2.census.gov/geo/tiger/GENZ2024/shp/cb_2024_17_tract_500k.zip

In Tableau, relate boundary `GEOID` to `Tract_FIPS` in the two project CSV files.
