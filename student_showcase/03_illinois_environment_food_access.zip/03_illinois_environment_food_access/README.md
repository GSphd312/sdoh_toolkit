# Illinois Environmental Burden & Food Access Dashboard

## Research question

**Where do high environmental burden and low-income, low-access food conditions overlap across Illinois census tracts, and which counties have the greatest concentration of these double-burden communities?**

## Dashboard

https://public.tableau.com/views/IllinoisTractHealthExplorer/Dashboard1?:showVizHome=no

## Included data

- `data/illinois_census_tract_tableau.csv`: tract-level Illinois EJI data prepared for Tableau.
- `data/illinois_food_access_tableau.csv`: tract-level USDA food-access data prepared for Tableau.
- `data/illinois_census_tract_data_dictionary.csv`: EJI field documentation.
- `data/illinois_food_access_data_dictionary.csv`: food-access field documentation.

## Census boundaries

The Tableau workbook uses the U.S. Census Bureau 2024 Illinois 500k census tract cartographic boundary file. See `boundaries/README.md` for the authoritative download link.

Relate `GEOID` in the Census boundary table to `Tract_FIPS` in both CSV files. Keep the fields as text so leading zeros are preserved.

## R script

Run:

```r
source("scripts/01_build_double_burden_analysis.R")
```

The script joins the two included tract tables and creates the dashboard's double-burden classification and county summary.

## Valid EJI values

Some public EJI files use negative sentinel values for unavailable ranks. For percentile analysis, treat only values from 0 through 1 as valid.
