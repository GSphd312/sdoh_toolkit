# Data sources

- HRSA Health Center data: https://data.hrsa.gov/data/download
- CDC/ATSDR Social Vulnerability Index: https://www.atsdr.cdc.gov/place-health/php/svi/index.html
- CDC/ATSDR Environmental Justice Index: https://www.atsdr.cdc.gov/place-health/php/eji/index.html
- County Health Rankings & Roadmaps: https://www.countyhealthrankings.org/health-data

The county context CSV is a prepared analysis table from the toolkit workflow. Before final publication, preserve the original upstream source/year documentation for every field, especially `depression_pct`.
