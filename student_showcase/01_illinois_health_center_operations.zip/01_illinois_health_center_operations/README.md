# Illinois Health Center Operations & Community Health

## Research question

**How are health center locations and operating hours distributed across Illinois, and how do county-level vulnerability and health indicators vary across the state?**

## Dashboard

https://public.tableau.com/views/Practice_17878919948750/ILHealthCenterEJI?:showVizHome=no

## Included data

- `data/hrsa_health_centers_illinois.csv` contains the Illinois-only HRSA records used for the health-center map and operating-hours KPIs. This extract contains **552 records**.
- `data/sdoh_il_tableau.csv` contains the prepared Illinois county-level community context measures used for SVI, EJI, smoking, depression, and related indicators.
- `data/dashboard_data_dictionary.csv` documents the principal dashboard fields.

## Important interpretation

The dashboard total of 552 is a count of HRSA records in the supplied extract. It should not be described as 552 unique physical facilities. The `Health Center Location Identification Number` field is not unique in this extract.

## R script

Run:

```r
source("scripts/01_prepare_dashboard_fields.R")
```

The script creates `derived/hrsa_health_centers_illinois_dashboard.csv` with the operating-hours group and 50+ hours flag used in Tableau, and a simplified county-context file.
