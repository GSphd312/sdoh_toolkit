# Tableau calculated fields

## Operating Hours Group

```tableau
IF ISNULL([Operating Hours per Week]) THEN
    "Not Reported"
ELSEIF [Operating Hours per Week] >= 50 THEN
    "50+ Hours"
ELSEIF [Operating Hours per Week] >= 40 THEN
    "40-49 Hours"
ELSE
    "Under 40 Hours"
END
```

## 50 Plus Hours Flag

```tableau
IF [Operating Hours per Week] >= 50 THEN 1
ELSE 0
END
```

Recommended KPI aggregations:
- Records: `COUNT([Health Center Location Identification Number])`
- Average hours: `AVG([Operating Hours per Week])`
- 50+ hours: `SUM([50 Plus Hours Flag])`
- Counties represented: `COUNTD([County Equivalent Name])`
