library(readr)
library(dplyr)

dir.create("derived", showWarnings = FALSE)

hrsa <- read_csv("data/hrsa_health_centers_illinois.csv", show_col_types = FALSE)
county <- read_csv("data/sdoh_il_tableau.csv", col_types = cols(fips = col_character()), show_col_types = FALSE)

stopifnot(all(hrsa$`Site State Abbreviation` == "IL"))
stopifnot(nrow(county) == 102)

hrsa_dashboard <- hrsa %>%
  mutate(
    Operating_Hours_Group = case_when(
      is.na(`Operating Hours per Week`) ~ "Not Reported",
      `Operating Hours per Week` >= 50 ~ "50+ Hours",
      `Operating Hours per Week` >= 40 ~ "40-49 Hours",
      TRUE ~ "Under 40 Hours"
    ),
    Fifty_Plus_Hours_Flag = if_else(
      !is.na(`Operating Hours per Week`) & `Operating Hours per Week` >= 50,
      1L, 0L
    )
  )

county_dashboard <- county %>%
  select(fips, county_name, svi_overall, eji_overall, adult_smoking, depression_pct)

write_csv(hrsa_dashboard, "derived/hrsa_health_centers_illinois_dashboard.csv")
write_csv(county_dashboard, "derived/illinois_county_context_dashboard.csv")

cat("Illinois HRSA records:", nrow(hrsa_dashboard), "\n")
cat("Average operating hours:", mean(hrsa_dashboard$`Operating Hours per Week`, na.rm=TRUE), "\n")
cat("Records open 50+ hours:", sum(hrsa_dashboard$Fifty_Plus_Hours_Flag), "\n")
cat("Counties represented:", n_distinct(hrsa_dashboard$`County Equivalent Name`), "\n")
