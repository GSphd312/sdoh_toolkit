# Indiana Healthcare Access Dashboard

## Research question

**Which Indiana counties experience higher social vulnerability and relatively lower access to HRSA health centers?**

## Dashboard

https://public.tableau.com/views/IndianaHealthcareAccessDashboard/IndianaHealthcareAccessDashboard?:showVizHome=no

## Included data

- `data/indiana_tableau_county_master.csv`: one row per Indiana county; use for county maps, rankings, scatterplots, and KPIs.
- `data/indiana_tableau_hrsa_sites.csv`: active HRSA site-level point data.
- `data/indiana_tableau_dual_axis.csv`: flattened county + site table used when a single Tableau source is needed for a dual-axis map.
- `data/indiana_tableau_data_dictionary.csv`: source and field documentation.

## R script

Run:

```r
source("scripts/01_validate_and_rebuild_dual_axis.R")
```

The script validates county/site keys and rebuilds a dual-axis file from the included county and site tables. County-level measures repeat on site rows in the flattened file, so use `AVG` or `MIN` for those measures in Tableau rather than `SUM`.
