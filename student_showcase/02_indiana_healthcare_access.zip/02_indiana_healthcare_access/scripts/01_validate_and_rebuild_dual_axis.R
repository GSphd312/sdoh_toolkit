library(readr)
library(dplyr)
library(tidyr)

dir.create("derived", showWarnings = FALSE)

county <- read_csv(
  "data/indiana_tableau_county_master.csv",
  col_types = cols(County_FIPS = col_character(), State_FIPS = col_character()),
  show_col_types = FALSE
)

sites <- read_csv(
  "data/indiana_tableau_hrsa_sites.csv",
  col_types = cols(County_FIPS = col_character()),
  show_col_types = FALSE
)

stopifnot(nrow(county) == 92)
stopifnot(n_distinct(county$County_FIPS) == 92)
stopifnot(all(sites$County_FIPS %in% county$County_FIPS))

# Counties with sites: one output row per site.
site_rows <- county %>%
  inner_join(sites, by = "County_FIPS", suffix = c("", "_site")) %>%
  mutate(Site_Record = 1L, Map_Row_Type = "HRSA Site")

# Counties with no site: retain one placeholder row so the county polygon remains available.
no_site <- county %>%
  filter(!County_FIPS %in% sites$County_FIPS) %>%
  mutate(Site_Record = 0L, Map_Row_Type = "County Placeholder")

# bind_rows safely fills site fields with NA for placeholder counties.
dual_axis <- bind_rows(site_rows, no_site)

write_csv(county, "derived/indiana_tableau_county_master.csv")
write_csv(sites, "derived/indiana_tableau_hrsa_sites.csv")
write_csv(dual_axis, "derived/indiana_tableau_dual_axis_rebuilt.csv")

cat("Indiana counties:", nrow(county), "\n")
cat("HRSA site rows:", nrow(sites), "\n")
cat("Counties with at least one HRSA site:", n_distinct(sites$County_FIPS), "\n")
