# Data sources

- County Health Rankings & Roadmaps: https://www.countyhealthrankings.org/health-data
- CDC/ATSDR Social Vulnerability Index: https://www.atsdr.cdc.gov/place-health/php/svi/index.html
- CDC/ATSDR Environmental Justice Index: https://www.atsdr.cdc.gov/place-health/php/eji/index.html
- HRSA Area Health Resources Files: https://data.hrsa.gov/topics/health-workforce/ahrf
- HRSA Health Center data: https://data.hrsa.gov/data/download

Detailed field-level source URLs are also included in `data/indiana_tableau_data_dictionary.csv`.
